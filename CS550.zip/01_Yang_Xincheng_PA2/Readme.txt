1. Make sure you installed JAVA in your computer, and then use command: 
	$ java -jar client.jar
to execute our program.

2. You can see command details use '$ help' in our program.

3. Before you execute a query, make sure you correctly configured some neighbors, we do not display your neighbors in command line.

4. You can dynamically add neighbors and files with command 'addneighbor' and 'register'

5. Before you obtain a file from other peer, make sure you execute query command first(we did exception handling for several illagal operation such as this).

6. You can use 'list' command view query hit result and previous query hit result.

7. We faked an event to listen query hit event and test the time elapse between query start and query hit, see 'perform.java' and 'query.java'.

8. You can see sample config file in 'sample config file' folder.


