/************************** for PA 2 *******************************/

1. Make sure you installed JAVA in your computer, and then use command: 
	$ java -jar client.jar
to execute our program.

2. You can see command details use '$ help' in our program.

3. Before you execute a query, make sure you correctly configured some neighbors, we do not display your neighbors in command line.

4. You can dynamically add neighbors and files with command 'addneighbor' and 'register'

5. Before you obtain a file from other peer, make sure you execute query command first(we did exception handling for several illagal operation such as this).

6. You can use 'list' command view query hit result and previous query hit result.

7. You can see sample config file in 'sample config file' folder.



/************************** for PA 3 *******************************/
8. Make sure you have correct configuration file for each peers.(All peers should be exist  and detectable in the network) 



9. We will print informations for update/invalidate/poll.



10. Make sure the peers have configured the same approach(all push or all pull), if they have different approach, we will refuse the invalidate/poll request in our program. 


11. Default configuration file is "config.txt", you can put it in the same folder of the executable jar, our program will load it automatically, besides, you can use command $config [file] to load the configuration file.
